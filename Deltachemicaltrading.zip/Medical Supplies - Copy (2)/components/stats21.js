import React from 'react'

import PropTypes from 'prop-types'

import './features11.css'

const Features11 = (props) => {
  return (
    <div className="features11-layout251 thq-section-padding">
      <div className="features11-max-width thq-section-max-width">
        <div className="thq-flex-row features11-section-title">
          <div className="features11-column thq-flex-column">
            <span className="thq-body-small">{props.slogan}</span>
            <h2 className="thq-heading-2 features11-text1">
              {props.sectionTitle}
            </h2>
          </div>
          <span className="thq-body-small">{props.sectionDescription}</span>
        </div>
        <div className="features11-content">
          <div className="features11-row thq-flex-row">
            <div className="features11-feature1 thq-flex-column">
              <img
                alt={props.feature1ImageAlt}
                src={props.feature1ImageSrc}
                className="thq-img-ratio-4-3 features11-feature1-image"
              />
              <div className="features11-content1 thq-flex-column">
                <h3 className="thq-heading-3">{props.feature1Title}</h3>
                <span className="thq-body-small">
                  {props.feature1Description}
                </span>
              </div>
            </div>
            <div className="features11-feature2 thq-flex-column">
              <img
                alt={props.feature2ImageAlt}
                src={props.feature2ImageSrc}
                className="thq-img-ratio-4-3 features11-feature2-image"
              />
              <div className="features11-content2 thq-flex-column">
                <h3 className="thq-heading-3">{props.feature2Title}</h3>
                <span className="thq-body-small">
                  {props.feature2Description}
                </span>
              </div>
            </div>
            <div className="features11-feature3 thq-flex-column">
              <img
                alt={props.feature3ImageAlt}
                src={props.feature3ImageSrc}
                className="thq-img-ratio-4-3 features11-feature3-image"
              />
              <div className="features11-content3 thq-flex-column">
                <h3 className="thq-heading-3">{props.feature3Title}</h3>
                <span className="thq-body-small">
                  {props.feature3Description}
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="features11-actions">
          <button className="thq-button-filled features11-button">
            <span className="thq-body-small">{props.mainAction}</span>
          </button>
          <button className="thq-button-outline features11-button1">
            <span className="thq-body-small">{props.secondaryAction}</span>
          </button>
        </div>
      </div>
    </div>
  )
}

Features11.defaultProps = {
  mainAction: 'Shop Now',
  feature2Title: 'High-Quality Materials',
  feature2ImageSrc:
    'https://images.unsplash.com/photo-1666886573681-a8fbe983a3fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNjMzNzYzMXw&ixlib=rb-4.0.3&q=80&w=1080',
  feature1Title: 'Wide Range of Products',
  feature2ImageAlt: 'High-Quality Materials Image',
  feature1Description:
    'Choose from a variety of medical supplies including stethoscopes, gloves, face masks, and more.',
  feature3ImageSrc:
    'https://images.unsplash.com/photo-1591981813227-fb37f0cf04ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNjMzNzYzMnw&ixlib=rb-4.0.3&q=80&w=1080',
  slogan: 'Quality Medical Supplies You Can Trust',
  feature3Title: 'Fast Shipping',
  feature3Description:
    'Enjoy fast and reliable shipping options to get your medical supplies when you need them.',
  feature3ImageAlt: 'Fast Shipping Image',
  feature1ImageAlt: 'Wide Range of Products Image',
  sectionDescription:
    'Discover the key features that make Delta Chemical Trading the top choice for medical supplies and healthcare products.',
  secondaryAction: 'Learn More',
  feature1ImageSrc:
    'https://images.unsplash.com/photo-1525328437458-0c4d4db7cab4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNjMzNzYzMnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature2Description:
    'Our products are made from premium materials to ensure durability and reliability.',
  sectionTitle: 'Key Features',
}

Features11.propTypes = {
  mainAction: PropTypes.string,
  feature2Title: PropTypes.string,
  feature2ImageSrc: PropTypes.string,
  feature1Title: PropTypes.string,
  feature2ImageAlt: PropTypes.string,
  feature1Description: PropTypes.string,
  feature3ImageSrc: PropTypes.string,
  slogan: PropTypes.string,
  feature3Title: PropTypes.string,
  feature3Description: PropTypes.string,
  feature3ImageAlt: PropTypes.string,
  feature1ImageAlt: PropTypes.string,
  sectionDescription: PropTypes.string,
  secondaryAction: PropTypes.string,
  feature1ImageSrc: PropTypes.string,
  feature2Description: PropTypes.string,
  sectionTitle: PropTypes.string,
}

export default Features11
