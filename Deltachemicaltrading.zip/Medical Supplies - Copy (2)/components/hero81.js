import React from 'react'

import PropTypes from 'prop-types'

import './stats21.css'

const Stats21 = (props) => {
  return (
    <div className="stats21-container thq-section-padding">
      <div className="stats21-max-width thq-section-max-width">
        <div className="thq-flex-column">
          <img
            alt={props.image1Alt}
            src={props.image1Src}
            className="thq-img-ratio-1-1 stats21-image"
          />
        </div>
        <div className="stats21-container2 thq-flex-column">
          <span className="thq-body-small">{props.content1}</span>
          <h2 className="thq-heading-2">{props.heading1}</h2>
          <p className="thq-body-large">{props.content2}</p>
          <div className="stats21-container3 thq-grid-2">
            <div className="stats21-container4">
              <h2 className="thq-heading-2">{props.stat1}</h2>
              <span className="thq-body-small">{props.stat1Description}</span>
            </div>
            <div className="stats21-container5">
              <h2 className="thq-heading-2">{props.stat2}</h2>
              <span className="thq-body-small">{props.stat2Description}</span>
            </div>
          </div>
          <div className="stats21-container6 thq-grid-2">
            <div className="stats21-container7">
              <h2 className="thq-heading-2">{props.stat3}</h2>
              <span className="thq-body-small">{props.stat3Description}</span>
            </div>
            <div className="stats21-container8">
              <h2 className="thq-heading-2">{props.stat4}</h2>
              <span className="thq-body-small">{props.stat4Description}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

Stats21.defaultProps = {
  stat1: 'Trusted Partner Since 1930s',
  content1:
    'Delta Chemical Trading has been serving the industry for over 90 years, establishing a strong reputation as a reliable and trusted partner.',
  content2:
    'With a focus on quality and customer satisfaction, Delta Chemical Trading continues to provide top-notch medical supplies to healthcare professionals.',
  image1Alt: 'Stethoscope image',
  stat3: 'Wide Range of Products',
  stat4: 'Accessible Online Store',
  stat2Description: 'High-Quality Medical Supplies',
  image1Src:
    'https://images.unsplash.com/photo-1612636322033-f48f76c34bab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNjMzNzYzMXw&ixlib=rb-4.0.3&q=80&w=1080',
  heading1: 'Why Choose Delta Chemical Trading?',
  stat4Description:
    'Easy and convenient online shopping experience for all your medical supply needs.',
  stat2: 'Quality Assurance',
  stat3Description:
    'From stethoscopes to other healthcare products, Delta Chemical Trading offers a diverse selection to meet various needs.',
  stat1Description:
    'With decades of experience, Delta Chemical Trading has built a strong foundation of trust and reliability in the industry.',
}

Stats21.propTypes = {
  stat1: PropTypes.string,
  content1: PropTypes.string,
  content2: PropTypes.string,
  image1Alt: PropTypes.string,
  stat3: PropTypes.string,
  stat4: PropTypes.string,
  stat2Description: PropTypes.string,
  image1Src: PropTypes.string,
  heading1: PropTypes.string,
  stat4Description: PropTypes.string,
  stat2: PropTypes.string,
  stat3Description: PropTypes.string,
  stat1Description: PropTypes.string,
}

export default Stats21
