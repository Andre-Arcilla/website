import React from 'react'

import PropTypes from 'prop-types'

import './hero81.css'

const Hero81 = (props) => {
  return (
    <div className="hero81-header26 thq-section-padding">
      <div className="hero81-max-width thq-flex-column thq-section-max-width">
        <div className="hero81-column">
          <div className="hero81-content">
            <h1 className="hero81-text thq-heading-1">{props.heading1}</h1>
            <p className="hero81-text1 thq-body-large">{props.content1}</p>
            <div className="hero81-actions">
              <button className="thq-button-filled hero81-button">
                <span className="thq-body-small">{props.action1}</span>
              </button>
              <button className="thq-button-outline hero81-button1">
                <span className="thq-body-small">{props.action2}</span>
              </button>
            </div>
          </div>
        </div>
        <img
          alt={props.image1Alt}
          src={props.image1Src}
          className="thq-img-ratio-16-9"
        />
      </div>
    </div>
  )
}

Hero81.defaultProps = {
  image1Alt: 'Stethoscope image',
  content1: 'Providing high-quality medical supplies since the 1930s',
  action2: 'Shop Now',
  image1Src:
    'https://images.unsplash.com/photo-1550831106-f8d5b6f1abe9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNjMzNzYzMXw&ixlib=rb-4.0.3&q=80&w=1080',
  heading1: 'Trusted Partner in Medical Supplies',
  action1: 'Learn More',
}

Hero81.propTypes = {
  image1Alt: PropTypes.string,
  content1: PropTypes.string,
  action2: PropTypes.string,
  image1Src: PropTypes.string,
  heading1: PropTypes.string,
  action1: PropTypes.string,
}

export default Hero81
